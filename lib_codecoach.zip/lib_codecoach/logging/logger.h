//
// Created by andres on 5/10/25.
//

#ifndef LIB_CODECOACH_LOGGER_H
#define LIB_CODECOACH_LOGGER_H


class logger {
};


#endif //LIB_CODECOACH_LOGGER_H