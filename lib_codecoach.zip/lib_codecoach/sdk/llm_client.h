//
// Created by andres on 5/10/25.
//

#ifndef LIB_CODECOACH_LLM_CLIENT_H
#define LIB_CODECOACH_LLM_CLIENT_H

#endif //LIB_CODECOACH_LLM_CLIENT_H
//interfaz abstracta para provedores