//
// Created by andres on 5/10/25.
//

#ifndef LIB_CODECOACH_LLM_CLIENT_OPENAI_H
#define LIB_CODECOACH_LLM_CLIENT_OPENAI_H


class llm_client_openai {
};


#endif //LIB_CODECOACH_LLM_CLIENT_OPENAI_H
//inmplementaciopn con api