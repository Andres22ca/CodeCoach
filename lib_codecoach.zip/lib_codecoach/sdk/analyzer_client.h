//
// Created by andres on 5/10/25.
//

#ifndef LIB_CODECOACH_ANALYZER_CLIENT_H
#define LIB_CODECOACH_ANALYZER_CLIENT_H


class analyzer_client {
};


#endif //LIB_CODECOACH_ANALYZER_CLIENT_H
// implementar el analyze al llm