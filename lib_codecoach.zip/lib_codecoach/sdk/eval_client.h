//
// Created by andres on 5/10/25.
//

#ifndef LIB_CODECOACH_EVAL_CLIENT_H
#define LIB_CODECOACH_EVAL_CLIENT_H


class eval_client {
};


#endif //LIB_CODECOACH_EVAL_CLIENT_H
// Implementar un post y run al motor de evaluacion