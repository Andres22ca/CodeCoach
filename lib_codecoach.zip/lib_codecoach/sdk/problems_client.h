//
// Created by andres on 5/10/25.
//

#ifndef LIB_CODECOACH_PROBLEMS_CLIENT_H
#define LIB_CODECOACH_PROBLEMS_CLIENT_H


class problems_client {
};


#endif //LIB_CODECOACH_PROBLEMS_CLIENT_H
// implementar llamadas http al gestor de problemas