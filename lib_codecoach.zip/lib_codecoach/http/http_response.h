//
// Created by andres on 5/10/25.
//

#ifndef LIB_CODECOACH_HTTP_RESPONSE_H
#define LIB_CODECOACH_HTTP_RESPONSE_H


class http_response {
};


#endif //LIB_CODECOACH_HTTP_RESPONSE_H
// implementar llamadas http al gestor de problemas