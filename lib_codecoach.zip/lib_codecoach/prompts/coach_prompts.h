//
// Created by andres on 5/10/25.
//

#ifndef LIB_CODECOACH_COACH_PROMTPS_H
#define LIB_CODECOACH_COACH_PROMTPS_H


class coach_prompts {
};


#endif //LIB_CODECOACH_COACH_PROMTPS_H